/**
 * Patient Registration Form - Client-side Interactive Script
 */

document.addEventListener('DOMContentLoaded', () => {
    function getFormElement(id) {
        if (document.getElementById('m_codAtencion')) {
            return document.getElementById('m_' + id) || document.getElementById(id);
        }
        return document.getElementById(id) || document.getElementById('m_' + id);
    }

    // Form and input elements
    const patientForm = document.getElementById('patientForm');
    const tipoServicioSelect = getFormElement('tipoServicio');
    const codAtencionInput = getFormElement('codAtencion');
    const dniInput = getFormElement('dni');
    const nombresInput = getFormElement('nombres');
    const apellidosInput = getFormElement('apellidos');
    const medSolicitanteSelect = getFormElement('medSolicitante');
    const fileUploadInput = getFormElement('ordenServicio');
    const fileUploadStatus = getFormElement('fileUploadStatus');
    const modalContainer = document.getElementById('patientRegistrationModal');
    const modalOverlay = document.getElementById('patientRegistrationModal') ? document.getElementById('patientRegistrationModal').parentElement : null;
    const fecRegistroInput = getFormElement('fecRegistro');
    const fecEntregaInput = getFormElement('fecEntrega');

    // Buttons
    const btnValidar = getFormElement('btnValidar');
    const btnBuscar = getFormElement('btnBuscar');
    const btnCopiar = getFormElement('btnCopiar');
    const btnRegistro = getFormElement('btnRegistro');
    const btnSalir = getFormElement('btnSalir');
    const closeHeaderBtn = getFormElement('closeHeaderBtn');

    // Sample database for DNI simulation
    const dniDatabase = {
        '11111111': { nombres: 'Carlos Andrés', apellidos: 'Mendoza Rivas', edad: '34', sexo: 'M', tel: '987654321' },
        '22222222': { nombres: 'María Elena', apellidos: 'López Huamán', edad: '28', sexo: 'F', tel: '955443322' },
        '33333333': { nombres: 'Jorge Luis', apellidos: 'Quispe Mamani', edad: '45', sexo: 'M', tel: '912345678' },
        '44444444': { nombres: 'Ana Sofía', apellidos: 'Castillo Vega', edad: '19', sexo: 'F', tel: '966778899' },
        '55555555': { nombres: 'Roberto Carlos', apellidos: 'Guerrero Silva', edad: '52', sexo: 'M', tel: '944112233' }
    };

    // Helpers para formato de fecha (DD/MM/YYYY)
    function formatDate(date) {
        const dd = String(date.getDate()).padStart(2, '0');
        const mm = String(date.getMonth() + 1).padStart(2, '0');
        const yyyy = date.getFullYear();
        return `${dd}/${mm}/${yyyy}`;
    }

    function formatDisplayDate(dateStr) {
        if (!dateStr) return '';
        if (dateStr instanceof Date) return formatDate(dateStr);
        if (dateStr.includes('/')) return dateStr;
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
        return dateStr;
    }

    // Inicializar fechas de registro y entrega
    if (fecRegistroInput) {
        fecRegistroInput.value = formatDisplayDate(new Date());
    }
    if (fecEntregaInput) {
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 4);
        fecEntregaInput.value = formatDisplayDate(deliveryDate);
    }

    /* ==========================================================================
       TOAST SYSTEM (NOTIFICACIONES FLOTANTES)
       ========================================================================== */
    function showToast(message, type = 'success') {
        let container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'toast-container';
            document.body.appendChild(container);
        }

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        let iconHtml = '<i class="fa-solid fa-circle-check"></i>';
        if (type === 'error') {
            iconHtml = '<i class="fa-solid fa-circle-exclamation"></i>';
        } else if (type === 'info') {
            iconHtml = '<i class="fa-solid fa-circle-info"></i>';
        }

        toast.innerHTML = `${iconHtml} <span>${message}</span>`;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastSlideIn 0.3s ease reverse forwards';
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3500);
    }
    window.showToast = showToast;

    // Autocompletar Código de Atención al seleccionar el Tipo de Servicio
    if (tipoServicioSelect) {
        tipoServicioSelect.addEventListener('change', () => {
            const currentYearLastTwo = String(new Date().getFullYear()).slice(-2);
            let prefix = '';
            if (tipoServicioSelect.value === 'EXAMEN DE MUESTRA POR HE') {
                prefix = `${currentYearLastTwo}Q-`;
            } else if (tipoServicioSelect.value === 'PAPANICOLAOU') {
                prefix = `${currentYearLastTwo}C-`;
            }

            if (prefix) {
                codAtencionInput.value = prefix;
                codAtencionInput.focus();
            } else {
                codAtencionInput.value = '';
            }
        });
    }

    /* ==========================================================================
       VALIDAR COD. ATENCION
       ========================================================================== */
    btnValidar.addEventListener('click', () => {
        const value = codAtencionInput.value.trim().toUpperCase();
        if (!value) {
            showToast('Por favor, ingrese un Código de Atención para validar.', 'error');
            codAtencionInput.focus();
            return;
        }

        // Check if code is repeated
        let repeated = false;
        const checkDuplicate = (dataArr) => {
            if (!Array.isArray(dataArr)) return false;
            return dataArr.some(item => {
                const cod = (item.cod_atencion || item.codAtencion || '').trim().toUpperCase();
                return cod === value;
            });
        };

        if (window.patientDatabase && checkDuplicate(window.patientDatabase)) repeated = true;
        else {
            const localBackup = localStorage.getItem('patientDatabaseLocal');
            if (localBackup) {
                try {
                    const parsed = JSON.parse(localBackup);
                    if (checkDuplicate(parsed)) repeated = true;
                } catch (e) {
                    console.error(e);
                }
            }
        }

        if (repeated) {
            alert(`El código de atención "${value}" ya está registrado. Por favor, cámbielo por otro.`);
            showToast(`Código duplicado: "${value}". Cambiar por otro.`, 'error');
            codAtencionInput.focus();
            return;
        }

        // Simple validation rule: check if it matches a clinical code pattern
        btnValidar.disabled = true;
        btnValidar.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Validando';

        setTimeout(() => {
            btnValidar.disabled = false;
            btnValidar.innerText = 'Validar';
            
            const pattern = /^[0-9]+[QIC]-[0-9]+$/i;
            const patternOld = /^[QIC]-[0-9]+$/i;
            if (pattern.test(value) || patternOld.test(value)) {
                showToast(`Código de Atención "${value}" validado con éxito y disponible.`, 'success');
            } else {
                showToast(`Código "${value}" validado y disponible (Formato sugerido: AÑOServicio-Número, ej: 26Q-214).`, 'info');
            }
        }, 800);
    });

    /* ==========================================================================
       BUSCAR DNI (SIMULACION DE CONSULTA API RENIEC)
       ========================================================================== */
    btnBuscar.addEventListener('click', performDniSearch);
    dniInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            performDniSearch();
        }
    });

    function performDniSearch() {
        const dni = dniInput.value.trim();
        if (!dni || dni.length !== 8 || isNaN(dni)) {
            showToast('Por favor, ingrese un DNI válido de 8 dígitos.', 'error');
            dniInput.focus();
            return;
        }

        btnBuscar.disabled = true;
        btnBuscar.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

        setTimeout(() => {
            btnBuscar.disabled = false;
            btnBuscar.innerText = 'Buscar';

            if (dniDatabase[dni]) {
                const data = dniDatabase[dni];
                nombresInput.value = data.nombres.toUpperCase();
                apellidosInput.value = data.apellidos.toUpperCase();
                const edadEl = getFormElement('edad');
                if (edadEl) edadEl.value = data.edad;
                const sexoEl = getFormElement('sexo');
                if (sexoEl) sexoEl.value = data.sexo;
                const telefonoEl = getFormElement('telefono');
                if (telefonoEl) telefonoEl.value = data.tel;
                
                showToast('DNI encontrado en la base de datos de RENIEC. Datos cargados.', 'success');
            } else {
                showToast('DNI no encontrado. Por favor, registre los datos manualmente.', 'info');
                nombresInput.focus();
            }
        }, 1000);
    }

    /* ==========================================================================
       MEDICO SOLICITANTE: COPIAR Y REGISTRAR
       ========================================================================== */
    // Registrar Médico Solicitante
    btnCopiar.addEventListener('click', () => {
        const docName = medSolicitanteSelect.value.trim().toUpperCase();
        if (!docName) {
            showToast('Por favor, ingrese el nombre del médico para registrar.', 'error');
            medSolicitanteSelect.focus();
            return;
        }

        let normalizedDoc = docName;
        if (!normalizedDoc.startsWith('DR. ') && !normalizedDoc.startsWith('DRA. ') && !normalizedDoc.startsWith('DR ') && !normalizedDoc.startsWith('DRA ')) {
            const firstWord = normalizedDoc.split(' ').filter(w => w !== 'DR' && w !== 'DRA' && w !== 'DR.' && w !== 'DRA.')[0] || '';
            const namesFeminine = ['MARIA', 'ANA', 'CLAUDIA', 'SANDRA', 'ELIZABETH', 'ROSA', 'VIVIANA', 'MIRTHA', 'MERY', 'MARY', 'ELEANA', 'CYNTHIA', 'NATALY', 'CARMEN', 'LUZ', 'PATRICIA', 'JUANA', 'SILVIA', 'BEATRIZ', 'MONICA', 'LAURA', 'GABRIELA'];
            const isFem = namesFeminine.some(n => firstWord.toUpperCase().includes(n));
            normalizedDoc = (isFem ? 'DRA. ' : 'DR. ') + normalizedDoc;
        }

        const doctorsDB = window.doctorsDatabase || [];
        const exists = doctorsDB.some(d => d.doctor.trim().toUpperCase() === normalizedDoc.trim().toUpperCase());
        if (exists) {
            showToast(`El médico "${normalizedDoc}" ya se encuentra registrado.`, 'info');
            medSolicitanteSelect.value = normalizedDoc;
            return;
        }

        const docData = {
            doctor: normalizedDoc,
            colegiado: '',
            especializacion: '',
            tipo: 'DR. CLIENTE',
            provincia: '',
            telefono: '',
            correo: '',
            firma: ''
        };

        doctorsDB.unshift(docData);

        if (window.supabase && typeof window.SUPABASE_CONFIG !== 'undefined') {
            const supabase = window.supabase;
            const usingSupabase = !!(supabase && window.SUPABASE_CONFIG);
            if (usingSupabase) {
                supabase
                    .from('doctores')
                    .insert([{
                        nombre: docData.doctor,
                        cmp: docData.colegiado,
                        rne: docData.especializacion,
                        tipo: docData.tipo,
                        provincia: docData.provincia,
                        telefono: docData.telefono,
                        correo: docData.correo,
                        firma: docData.firma
                    }])
                    .then(({ error }) => {
                        if (error) console.error("Error al registrar doctor en Supabase:", error);
                    });
            }
        }

        if (typeof window.populateModalDoctorsSelect === 'function') {
            window.populateModalDoctorsSelect();
        }

        medSolicitanteSelect.value = normalizedDoc;
        showToast(`Médico "${normalizedDoc}" registrado e ingresado con éxito.`, 'success');
    });

    // Guardar
    btnRegistro.addEventListener('click', () => {
        btnCopiar.click();
    });

    /* ==========================================================================
       MANEJO DE ARCHIVOS (ORDEN SERVICIO)
       ========================================================================== */
    fileUploadInput.addEventListener('change', (e) => {
        const files = e.target.files;
        if (files.length === 0) {
            fileUploadStatus.innerText = 'Sin archivos seleccionados';
        } else if (files.length === 1) {
            fileUploadStatus.innerText = files[0].name;
        } else {
            fileUploadStatus.innerText = `${files.length} archivos seleccionados`;
        }
    });

    /* ==========================================================================
       INTERACCIONES DE SALIDA Y CIERRE (ANIMACION Y REAPERTURA)
       ========================================================================== */
    function closeModal() {
        if (modalContainer && modalOverlay) {
            modalContainer.style.transform = 'translateY(20px) scale(0.95)';
            modalContainer.style.opacity = '0';
            modalOverlay.style.opacity = '0';
            modalOverlay.style.transition = 'opacity 0.3s ease';
            modalContainer.style.transition = 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)';

            setTimeout(() => {
                modalOverlay.classList.remove('active');
                const regModalOverlay = document.getElementById('registrationModalOverlay');
                if (regModalOverlay) regModalOverlay.classList.remove('active');
                document.body.style.overflow = '';
                modalOverlay.style.opacity = '';
                modalContainer.style.opacity = '';
                modalContainer.style.transform = '';
            }, 300);
        } else {
            const regModalOverlay = document.getElementById('registrationModalOverlay');
            if (regModalOverlay) regModalOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    function showReopenWidget() {
        // Create an elegant widget to reopen modal
        let widget = document.getElementById('reopenWidget');
        if (!widget) {
            widget = document.createElement('div');
            widget.id = 'reopenWidget';
            widget.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                text-align: center;
                background-color: #ffffff;
                padding: 30px;
                border-radius: 8px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                z-index: 500;
                animation: modalAppear 0.3s ease;
            `;
            widget.innerHTML = `
                <h3 style="margin-bottom: 15px; color: var(--primary-color);">Formulario Cerrado</h3>
                <p style="margin-bottom: 20px; font-size: 0.9rem; color: #6b7280;">Puedes volver a abrir la ficha de registro del paciente presionando el botón de abajo.</p>
                <button type="button" class="btn btn-primary" id="btnReabrir">Abrir Ficha de Registro</button>
            `;
            document.body.appendChild(widget);

            document.getElementById('btnReabrir').addEventListener('click', () => {
                widget.remove();
                modalOverlay.style.display = 'flex';
                // Trigger reflow
                modalOverlay.offsetHeight;
                modalOverlay.style.opacity = '1';
                modalContainer.style.transform = 'translateY(0) scale(1)';
                modalContainer.style.opacity = '1';
            });
        }
    }

    btnSalir.addEventListener('click', closeModal);
    closeHeaderBtn.addEventListener('click', closeModal);

    /* ==========================================================================
       GUARDAR FORMULARIO
       ========================================================================== */
    patientForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Extra logic verification
        const nombres = nombresInput.value.trim();
        const apellidos = apellidosInput.value.trim();
        const value = (codAtencionInput.value || '').trim().toUpperCase();

        if (!nombres || !apellidos) {
            showToast('Por favor complete los campos obligatorios de Nombres y Apellidos.', 'error');
            return;
        }

        if (!value) {
            showToast('Por favor complete el Código de Atención.', 'error');
            codAtencionInput.focus();
            return;
        }

        // Check if code is repeated
        let repeated = false;
        const checkDuplicate = (dataArr) => {
            if (!Array.isArray(dataArr)) return false;
            return dataArr.some(item => {
                const cod = (item.cod_atencion || item.codAtencion || '').trim().toUpperCase();
                return cod === value;
            });
        };

        if (window.patientDatabase && checkDuplicate(window.patientDatabase)) repeated = true;
        else {
            const localBackup = localStorage.getItem('patientDatabaseLocal');
            if (localBackup) {
                try {
                    const parsed = JSON.parse(localBackup);
                    if (checkDuplicate(parsed)) repeated = true;
                } catch (err) {
                    console.error(err);
                }
            }
        }

        if (repeated) {
            alert(`El código de atención "${value}" ya está registrado. Por favor, cambie el código por otro ya que no se permiten códigos duplicados.`);
            showToast(`Código de Atención repetido: "${value}". Debe cambiarlo.`, 'error');
            codAtencionInput.focus();
            return;
        }

        // Show loading spinner in Save button
        const btnGuardar = getFormElement('btnGuardar');
        const originalText = btnGuardar ? btnGuardar.innerText : 'Guardar';
        if (btnGuardar) {
            btnGuardar.disabled = true;
            btnGuardar.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Guardando...';
        }

        setTimeout(() => {
            try {
                // Helper to get form input values
                const getValueOf = (id) => {
                    const el = getFormElement(id);
                    return el ? el.value.trim() : '';
                };

                const getCheckedOf = (id) => {
                    const el = getFormElement(id);
                    return el ? el.checked : false;
                };

                const serviceVal = getValueOf('tipoServicio');
                let service = 'Q';
                if (serviceVal === 'INMUNOHISTOQUIMICA') {
                    service = 'I';
                } else if (serviceVal === 'PAPANICOLAOU') {
                    service = 'C';
                } else if (serviceVal === 'CITOLOGÍA ESPECIAL') {
                    service = 'C';
                } else if (serviceVal === 'REVISIÓN DE LAMINA') {
                    service = 'Q';
                } else {
                    service = 'Q';
                }

                const customEspecimen = getValueOf('telContacto'); // Labeled Órgano / Muestra
                const especimen = customEspecimen ? customEspecimen.trim().toUpperCase() : '';
                const motivoEstudioVal = getValueOf('motivoEstudio');

                const parseDisplayDate = (displayStr) => {
                    if (!displayStr) return '';
                    const parts = displayStr.split('/');
                    if (parts.length === 3) {
                        return `${parts[2]}-${parts[1]}-${parts[0]}`;
                    }
                    return displayStr;
                };

                const costo = parseFloat(getValueOf('costoTransp')) || 0;
                const adelanto = parseFloat(getValueOf('adelanto')) || 0;
                const resta = costo - adelanto;
                const pagado = !getCheckedOf('pagoPendiente');

                const nextId = window.patientDatabase && window.patientDatabase.length > 0
                    ? Math.max(...window.patientDatabase.map(x => x.id)) + 1
                    : 1;

                const newRecord = {
                    id: nextId,
                    service: service,
                    codAtencion: value,
                    dni: getValueOf('dni') || '0',
                    medSolicitante: getValueOf('medSolicitante').toUpperCase(),
                    nombres: nombres.toUpperCase(),
                    apellidos: apellidos.toUpperCase(),
                    paciente: `${nombres.toUpperCase()} ${apellidos.toUpperCase()}`,
                    especimen: especimen,
                    costo: costo,
                    adelanto: adelanto,
                    resta: resta,
                    fecRegistro: parseDisplayDate(getValueOf('fecRegistro')),
                    fecEntrega: parseDisplayDate(getValueOf('fecEntrega')),
                    pagado: pagado,
                    atrasado: false,

                    // Additional fields
                    edad: parseInt(getValueOf('edad')) || 0,
                    sexo: getValueOf('sexo').toUpperCase() || 'MASCULINO',
                    telefono: getValueOf('telefono'),
                    telContacto: especimen,
                    motivoEstudio: motivoEstudioVal ? motivoEstudioVal.trim().toUpperCase() : '',
                    clinica: getValueOf('clinica').toUpperCase()
                };

                if (newRecord.medSolicitante === 'SELECCIONAR') newRecord.medSolicitante = '';
                if (newRecord.sexo === 'M' || newRecord.sexo === 'MASCULINO') newRecord.sexo = 'MASCULINO';
                else if (newRecord.sexo === 'F' || newRecord.sexo === 'FEMENINO') newRecord.sexo = 'FEMENINO';
                else newRecord.sexo = 'MASCULINO';

                // Add to global database and trigger sync
                if (typeof window.savePatient === 'function') {
                    window.savePatient(newRecord);
                } else {
                    if (window.patientDatabase) {
                        window.patientDatabase.unshift(newRecord);
                    }
                    if (typeof window.triggerAutomaticBackup === 'function') {
                        window.triggerAutomaticBackup();
                    }
                    if (typeof window.refreshPatientTable === 'function') {
                        window.refreshPatientTable();
                    }
                }

                if (btnGuardar) {
                    btnGuardar.disabled = false;
                    btnGuardar.innerText = originalText;
                }

                showToast(`¡Paciente ${nombres} ${apellidos} registrado exitosamente!`, 'success');

                // Capture contextual fields to preserve for consecutive batch registration
                const savedMed = medSolicitanteSelect ? medSolicitanteSelect.value : '';
                const savedServ = tipoServicioSelect ? tipoServicioSelect.value : '';
                const clinicaEl = getFormElement('clinica');
                const savedClinica = clinicaEl ? clinicaEl.value : '';

                // Calculate next incremented attention code
                const generateNextCode = (lastCode) => {
                    if (!lastCode) return '';
                    const match = lastCode.match(/^([A-Z0-9]+-)(\d+)$/i);
                    if (match) {
                        const prefix = match[1];
                        const numStr = match[2];
                        const nextNum = parseInt(numStr, 10) + 1;
                        const paddedNum = String(nextNum).padStart(numStr.length, '0');
                        return prefix + paddedNum;
                    }
                    const matchEnd = lastCode.match(/^(.*?)(\d+)$/);
                    if (matchEnd) {
                        const prefix = matchEnd[1];
                        const numStr = matchEnd[2];
                        const nextNum = parseInt(numStr, 10) + 1;
                        const paddedNum = String(nextNum).padStart(numStr.length, '0');
                        return prefix + paddedNum;
                    }
                    return lastCode;
                };
                const nextCodeVal = generateNextCode(value);

                // Smart Form Reset
                patientForm.reset();
                if (fileUploadStatus) fileUploadStatus.innerText = 'Sin archivos seleccionados';
                const costoTranspEl = getFormElement('costoTransp');
                if (costoTranspEl) costoTranspEl.value = '0';
                const adelantoEl = getFormElement('adelanto');
                if (adelantoEl) adelantoEl.value = '0';

                // Preserve batch context (Doctor, Service, Clinic)
                if (medSolicitanteSelect && savedMed) medSolicitanteSelect.value = savedMed;
                if (tipoServicioSelect && savedServ) tipoServicioSelect.value = savedServ;
                if (clinicaEl && savedClinica) clinicaEl.value = savedClinica;

                // Auto-fill next incremented attention code
                if (codAtencionInput && nextCodeVal) {
                    codAtencionInput.value = nextCodeVal;
                }

                // Reset dates (Today & Today + 5)
                if (fecRegistroInput) {
                    fecRegistroInput.value = formatDate(new Date());
                }
                if (fecEntregaInput) {
                    const deliveryDate = new Date();
                    deliveryDate.setDate(deliveryDate.getDate() + 4);
                    fecEntregaInput.value = formatDate(deliveryDate);
                }

                // Place cursor focus on DNI input for immediate next entry
                if (dniInput) {
                    dniInput.focus();
                }

            } catch (err) {
                console.error(err);
                showToast('Ocurrió un error al guardar los datos del paciente.', 'error');
                if (btnGuardar) {
                    btnGuardar.disabled = false;
                    btnGuardar.innerText = originalText;
                }
            }
        }, 1000);
    });

    // Automatically convert all text inputs and textareas to uppercase and clean spaces on the fly
    document.querySelectorAll('input[type="text"], textarea').forEach(input => {
        input.addEventListener('input', (e) => {
            const target = e.target;
            const originalValue = target.value;
            const start = target.selectionStart;
            
            let value = originalValue.toUpperCase();
            
            // Si es codAtencion o dni, quitar todos los espacios
            if (target.id.includes('codAtencion') || target.id.includes('dni')) {
                value = value.replace(/\s+/g, '');
            } else {
                // Quitar espacios al inicio (leading space)
                if (value.startsWith(' ')) {
                    value = value.trimStart();
                }
                // Quitar espacio después de un guion (ej: "26C- 113" -> "26C-113")
                if (value.includes('- ')) {
                    value = value.replace(/-\s+/g, '-');
                }
                
                // Corregir ortografía de Papanicolaou y Citología Cervical (mayúsculas)
                const papanicolaouRegex = /\bpapa?ni[co]o?l?[a-z]{0,6}\b/gi;
                value = value.replace(papanicolaouRegex, 'PAPANICOLAOU');
                
                const citologiaRegex = /\bcito[lgj][ií]a\s+cervical\b/gi;
                value = value.replace(citologiaRegex, 'CITOLOGÍA CERVICAL');
            }
            
            if (originalValue !== value) {
                target.value = value;
                if (start !== null) {
                    const diff = originalValue.length - value.length;
                    const newPos = Math.max(0, start - diff);
                    target.setSelectionRange(newPos, newPos);
                }
            }
        });
    });

    // Cargar y poblar dinámicamente el listado de médicos solicitantes
    async function loadDoctorsSelect() {
        try {
            const select = getFormElement('medSolicitante');
            if (!select) return;
            if (select.tagName !== 'SELECT') return;

            const response = await fetch('doctores.json');
            if (!response.ok) throw new Error('Error loading doctores.json');
            const doctors = await response.json();
            

            select.innerHTML = '<option value="" selected>SELECCIONAR</option>';
            
            // Filtrar nombres únicos y ordenados de doctores válidos
            const uniqueDoctors = [...new Set(doctors
                .map(d => d.doctor.trim().toUpperCase())
                .filter(name => name && name !== 'SIN DATOS' && !name.includes('---'))
            )].sort();

            uniqueDoctors.forEach(doc => {
                const option = document.createElement('option');
                option.value = doc;
                option.text = doc;
                select.appendChild(option);
            });
        } catch (err) {
            console.error('Error al cargar la lista de doctores:', err);
        }
    }
    
    loadDoctorsSelect();

    // --- LÓGICA DE MENÚ LATERAL Y ACORDEÓN ---
    const appContainer = document.getElementById('appContainer');
    const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
    const sidebarBackdrop = document.getElementById('sidebarBackdrop');
    const adminGroupBtn = document.getElementById('adminGroupBtn');
    const adminGroup = document.getElementById('adminGroup');

    if (sidebarToggleBtn) {
        sidebarToggleBtn.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                appContainer.classList.toggle('sidebar-active');
            } else {
                appContainer.classList.toggle('collapsed');
            }
        });
    }

    if (sidebarBackdrop) {
        sidebarBackdrop.addEventListener('click', () => {
            appContainer.classList.remove('sidebar-active');
        });
    }

    if (adminGroupBtn && adminGroup) {
        adminGroupBtn.addEventListener('click', () => {
            adminGroup.classList.toggle('active');
        });
    }



    // --- LÓGICA DE DICTADO POR VOZ (GOOGLE WEB SPEECH) ---
    let dictationRecognition = null;
    let isDictating = false;
    let lastFocusedInput = null;

    // Registrar focus en los inputs para saber dónde insertar el dictado
    document.querySelectorAll('#patientForm input, #patientForm textarea, #patientForm select').forEach(el => {
        el.addEventListener('focus', () => {
            lastFocusedInput = el;
        });
    });

    const btnDictado = getFormElement('btnDictado');
    if (btnDictado) {
        btnDictado.addEventListener('click', () => {
            toggleDictation(btnDictado);
        });
    }

    function toggleDictation(btn) {
        if (typeof window.startDictation === 'function') {
            const targetId = (lastFocusedInput && lastFocusedInput.id) ? lastFocusedInput.id : 'm_nombres';
            window.startDictation(targetId);
            return;
        }

        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!window.SpeechRecognition) {
            showToast("Su navegador no soporta el dictado por voz de Google.", "error");
            return;
        }

        if (isDictating) {
            stopDictation(btn);
        } else {
            startDictation(btn);
        }
    }

    function startDictation(btn) {
        dictationRecognition = new window.webkitSpeechRecognition();
        dictationRecognition.lang = 'es-PE';
        dictationRecognition.continuous = true;
        dictationRecognition.interimResults = false;

        dictationRecognition.onstart = () => {
            isDictating = true;
            btn.classList.add('listening');
            btn.innerHTML = '<i class="fa-solid fa-microphone fa-beat" style="color: #ffffff;"></i> Escuchando...';
            showToast("Micrófono activado. Hable ahora...", "success");
        };

        dictationRecognition.onerror = (event) => {
            console.error("Speech Recognition Error:", event.error);
            if (event.error === 'not-allowed') {
                showToast("Acceso al micrófono denegado. Permítalo en su navegador.", "error");
            } else {
                showToast(`Error de dictado: ${event.error}`, "error");
            }
            stopDictation(btn);
        };

        dictationRecognition.onend = () => {
            stopDictation(btn);
        };

        dictationRecognition.onresult = (event) => {
            const resultIndex = event.resultIndex;
            const rawTranscript = event.results[resultIndex][0].transcript;
            const transcript = rawTranscript.replace(/[\u00a0\s]+/g, ' ').trim();
            console.log("Dictado:", transcript);
            processDictationResult(transcript);
        };

        dictationRecognition.start();
    }

    function stopDictation(btn) {
        if (dictationRecognition) {
            dictationRecognition.onend = null;
            dictationRecognition.onerror = null;
            dictationRecognition.stop();
            dictationRecognition = null;
        }
        isDictating = false;
        btn.classList.remove('listening');
        btn.innerHTML = '<i class="fa-solid fa-microphone"></i> Llenado por dictado';
    }

    function processDictationResult(text) {
        const rules = [
            { regex: /^(tipo de servicio|tipo servicio|servicio)\s+(.+)$/i, fieldId: 'tipoServicio' },
            { regex: /^(código de atención|codigo de atencion|código|codigo|atención|atencion)\s+(.+)$/i, fieldId: 'codAtencion' },
            { regex: /^(nombres?|nombre)\s+(.+)$/i, fieldId: 'nombres' },
            { regex: /^(apellidos?|apellido)\s+(.+)$/i, fieldId: 'apellidos' },
            { regex: /^(dni|documento|cédula|cedula)\s+(.+)$/i, fieldId: 'dni' },
            { regex: /^(edad)\s+(.+)$/i, fieldId: 'edad' },
            { regex: /^(teléfono|telefono|celular)\s+(.+)$/i, fieldId: 'telefono' },
            { regex: /^(sexo|género|genero)\s+(.+)$/i, fieldId: 'sexo' },
            { regex: /^(motivo|estudio|diagnóstico|diagnostico)\s+(.+)$/i, fieldId: 'motivoEstudio' },
            { regex: /^(clínica|clinica)\s+(.+)$/i, fieldId: 'clinica' },
            { regex: /^(costo|transporte|costo transporte)\s+(.+)$/i, fieldId: 'costoTransp' },
            { regex: /^(adelanto)\s+(.+)$/i, fieldId: 'adelanto' }
        ];

        let matched = false;
        for (const rule of rules) {
            const match = text.match(rule.regex);
            if (match) {
                let value = match[2].trim();
                const input = getFormElement(rule.fieldId);

                if (input) {
                    if (input.tagName === 'SELECT') {
                        const valLower = value.toLowerCase();
                        if (input.id.includes('tipoServicio')) {
                            if (valLower.includes('examen') || valLower.includes('muestra') || valLower.includes('he')) {
                                input.value = 'EXAMEN DE MUESTRA POR HE';
                            } else if (valLower.includes('papanicolau') || valLower.includes('papanicolaou')) {
                                input.value = 'PAPANICOLAOU';
                            }
                        } else if (input.id.includes('sexo')) {
                            if (valLower.includes('masculino') || valLower === 'm' || valLower === 'hombre') {
                                input.value = 'M';
                            } else if (valLower.includes('femenino') || valLower === 'f' || valLower === 'mujer') {
                                input.value = 'F';
                            } else {
                                input.value = 'O';
                            }
                        }
                    } else {
                        if (rule.fieldId.includes('nombres') || rule.fieldId.includes('apellidos')) {
                            value = value.toUpperCase();
                        }
                        if (rule.fieldId.includes('codAtencion') || rule.fieldId.includes('dni')) {
                            value = value.replace(/\s+/g, '').toUpperCase();
                        }
                        input.value = value;
                    }

                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    showToast(`Campo actualizado: ${value}`, "success");
                    matched = true;
                    break;
                }
            }
        }

        if (!matched) {
            let activeEl = document.activeElement;
            if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') && activeEl.closest('#patientForm')) {
                insertTextAtCursor(activeEl, text);
            } else if (lastFocusedInput) {
                insertTextAtCursor(lastFocusedInput, text);
            } else {
                const defaultInput = getFormElement('nombres');
                if (defaultInput) {
                    insertTextAtCursor(defaultInput, text);
                }
            }
        }
    }

    function insertTextAtCursor(input, text) {
        if (input.id.includes('nombres') || input.id.includes('apellidos')) {
            text = text.toUpperCase();
        }
        if (input.id.includes('codAtencion') || input.id.includes('dni')) {
            text = text.replace(/\s+/g, '').toUpperCase();
        }
        
        const start = input.selectionStart || 0;
        const end = input.selectionEnd || 0;
        const val = input.value;

        if (!val) {
            input.value = text;
        } else {
            const separator = (input.id.includes('codAtencion') || input.id.includes('dni')) ? '' : ' ';
            input.value = val.substring(0, start) + (start > 0 && val[start-1] !== ' ' && separator ? separator : '') + text + val.substring(end);
        }

        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.focus();

        const newPos = start + text.length + (val ? 1 : 0);
        input.setSelectionRange(newPos, newPos);
        showToast("Texto añadido", "success");
    }

    // Forzar mayúsculas en el modelo de datos para los inputs del formulario de registro y autolimpiar espacios del dictáfono
    document.addEventListener('input', (e) => {
        const target = e.target;
        if (!target) return;
        
        // Ignorar el editor de informes patológicos y áreas de texto de descripción extensa
        if (target.closest('#reportEditorModalOverlay') || target.classList.contains('editor-area')) {
            return;
        }

        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
            const type = target.getAttribute('type');
            if (target.tagName === 'TEXTAREA' || !type || ['text', 'search', 'email', 'url', 'tel', 'password'].includes(type.toLowerCase())) {
                const start = target.selectionStart;
                const originalValue = target.value;
                
                let value = originalValue.toUpperCase();
                
                // Si está dentro del formulario de registro de paciente
                if (target.closest('#patientForm')) {
                    if (target.id.includes('codAtencion') || target.id.includes('dni')) {
                        value = value.replace(/\s+/g, '');
                    } else {
                        if (value.startsWith(' ')) {
                            value = value.trimStart();
                        }
                        if (value.includes('- ')) {
                            value = value.replace(/-\s+/g, '-');
                        }
                        
                        const papanicolaouRegex = /\bpapa?ni[co]o?l?[a-z]{0,6}\b/gi;
                        value = value.replace(papanicolaouRegex, 'PAPANICOLAOU');
                        
                        const citologiaRegex = /\bcito[lgj][ií]a\s+cervical\b/gi;
                        value = value.replace(citologiaRegex, 'CITOLOGÍA CERVICAL');
                    }
                }
                
                if (originalValue !== value) {
                    target.value = value;
                    if (start !== null) {
                        const diff = originalValue.length - value.length;
                        const newPos = Math.max(0, start - diff);
                        target.setSelectionRange(newPos, newPos);
                    }
                }
            }
        }
    });

    // --- ATAJOS DE TECLADO PARA NAVEGACIÓN Y AUTOMATIZACIÓN DE MENÚ (DICTÁFONO / HARDWARE) ---
    document.addEventListener('keydown', function(e) {
        // Verificar combinaciones con Alt + Shift
        if (e.altKey && e.shiftKey) {
            const key = e.key.toLowerCase();
            
            switch (key) {
                case 'u':
                    e.preventDefault();
                    (document.querySelector('#btn-usuarios, [data-target="usuario"], [data-target="usuarios"], a[href*="view=user"]') || document.querySelector('.nav-item-btn[data-target="usuario"]'))?.click();
                    break;
                case 't':
                    e.preventDefault();
                    (document.querySelector('#btn-plantillas, [data-target="plantilla"], [data-target="plantillas"], a[href*="view=template"]') || document.querySelector('.nav-item-btn[data-target="plantilla"]'))?.click();
                    break;
                case 'd':
                    e.preventDefault();
                    (document.querySelector('#btn-doctores, [data-target="doctor"], [data-target="doctores"], a[href*="view=doctor"]') || document.querySelector('.nav-item-btn[data-target="doctor"]'))?.click();
                    break;
                case 'r':
                    e.preventDefault();
                    (document.querySelector('#btn-registro, #sidebarBtnRegistroPacientes, [data-target="registro"], a[href*="index.html"]') || document.querySelector('#btnNuevoPaciente'))?.click();
                    break;
                case 'l':
                    e.preventDefault();
                    (document.querySelector('#btn-listado, [data-target="pacientes"], [data-target="listado"], a.nav-item-btn[href*="reportes.html"]') || document.querySelector('.nav-item-btn[data-target="pacientes"]'))?.click();
                    break;
                case 'k': { // Siguiente (Next)
                    e.preventDefault();
                    const camposIndex = [
                        'codAtencion',
                        'dni',
                        'nombres',
                        'apellidos',
                        'telefono',
                        'medSolicitante',
                        'telContacto',
                        'motivoEstudio',
                        'clinica'
                    ];
                    const camposModal = [
                        'm_codAtencion',
                        'm_dni',
                        'm_nombres',
                        'm_apellidos',
                        'm_telefono',
                        'm_medSolicitante',
                        'm_telContacto',
                        'm_motivoEstudio',
                        'm_clinica'
                    ];

                    const activeEl = document.activeElement;
                    let targetList = camposIndex;

                    // Detectar si estamos en el modal flotante de reportes.html o en index.html
                    const modalOverlay = document.getElementById('registrationModalOverlay');
                    if (modalOverlay && (window.getComputedStyle(modalOverlay).display !== 'none')) {
                        targetList = camposModal;
                    }

                    let currentIndex = -1;
                    if (activeEl) {
                        currentIndex = targetList.indexOf(activeEl.id);
                    }

                    const nextIndex = (currentIndex + 1) % targetList.length;
                    const nextId = targetList[nextIndex];
                    const nextEl = document.getElementById(nextId);
                    if (nextEl) {
                        nextEl.focus();
                        if (typeof nextEl.select === 'function') {
                            nextEl.select();
                        }
                    }
                    break;
                }
                case 'g': { // Guardar (Save)
                    e.preventDefault();
                    
                    // 1. Modal de Edición de Reporte Patológico (re_btnGuardar)
                    const reportEditorModal = document.getElementById('reportEditorModalOverlay');
                    if (reportEditorModal && (reportEditorModal.classList.contains('active') || window.getComputedStyle(reportEditorModal).display !== 'none')) {
                        const reBtn = document.getElementById('re_btnGuardar');
                        if (reBtn) {
                            reBtn.click();
                            break;
                        }
                    }
                    
                    // 2. Modal de Registro de Pacientes (m_btnGuardar)
                    const regModal = document.getElementById('registrationModalOverlay');
                    if (regModal && (regModal.classList.contains('active') || window.getComputedStyle(regModal).display !== 'none')) {
                        const mBtn = document.getElementById('m_btnGuardar');
                        if (mBtn) {
                            mBtn.click();
                            break;
                        }
                    }
                    
                    // 3. Formulario de Plantillas (btnGuardarPlantillaForm)
                    const templatesView = document.getElementById('view-templates');
                    if (templatesView && window.getComputedStyle(templatesView).display !== 'none') {
                        const tplBtn = document.getElementById('btnGuardarPlantillaForm');
                        if (tplBtn) {
                            tplBtn.click();
                            break;
                        }
                    }
                    
                    // 4. Formulario de Doctores (btnGuardarDoctor)
                    const doctorsView = document.getElementById('view-doctors');
                    if (doctorsView && window.getComputedStyle(doctorsView).display !== 'none') {
                        const docBtn = document.getElementById('btnGuardarDoctor');
                        if (docBtn) {
                            docBtn.click();
                            break;
                        }
                    }

                    // 5. Vista General (index.html - btnGuardar)
                    const btn = document.getElementById('btnGuardar');
                    if (btn) {
                        btn.click();
                    }
                    break;
                }
            }
        }
    });
});
